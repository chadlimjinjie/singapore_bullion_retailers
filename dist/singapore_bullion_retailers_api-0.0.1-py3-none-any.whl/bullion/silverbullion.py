

'''
https://www.silverbullion.com.sg/Account/Login
__RequestVerificationToken: PuXNCzCEMh0cv0vl7ZF18UUtLO5WYH2iZ6OPMJmjNS7St2i0dLTey9M24gcfC6-izRkrWS6DUsqiAfIDQDF6cuLkDrU1
ReturnUrl: /
CopyCart: False
TokenCode: 
CaptchaToken: 
VerifyMethod: 
UsernameEmail: example@example.com
Password: 123456789
'''
async def login(email, password):

    # body_login = {
    #     "__RequestVerificationToken": "W7tAtfw6c-U5oHBwU37MqEW-xbw1etttu3RSzpNE_65Gh9DPdUmJjr6cMW90aVrMDv_2BcQURdhuZywfZfmLT127rM81",
    #     "ReturnUrl": "/",
    #     "CopyCart": "False",
    #     "TokenCode": "",
    #     "CaptchaToken": "",
    #     "VerifyMethod": "",
    #     "UsernameEmail": email,
    #     "Password": password
    # }

    # async with aiohttp.ClientSession() as session:

    #     async with session.post('https://www.silverbullion.com.sg/Account/Login', data=body_login) as resp:
    #         print(resp.status)
    #         data = await resp.text()
    #         print(data)



        

    return


