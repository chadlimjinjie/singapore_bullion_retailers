  # Singapore Bullion Retailers API

Programmatic functions for accessing Singapore bullion retailers API

https://www.bullionstar.com/developer/docs/api/
BullionStar Singapore
- Login function


(Development on hold)
Silver Bullion Singapore
- Login function (TODO)



Roadmap
- To release as a python package
- List products
- Order placing

